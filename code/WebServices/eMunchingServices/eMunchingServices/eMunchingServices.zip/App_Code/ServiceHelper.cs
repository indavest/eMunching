﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;

/// <summary>
/// Summary description for Helper
/// </summary>
public class ServiceHelper
{
    public ServiceHelper()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    /// <summary>
    /// Returns the base site URL
    /// </summary>
    public static string BaseSiteUrl
    {
        get
        {
            HttpContext context = HttpContext.Current;
            string baseUrl = context.Request.Url.Scheme + "://" + context.Request.Url.Authority + context.Request.ApplicationPath.TrimEnd('/') + '/';
            return baseUrl;
        }
    }

    /// <summary>
    /// Returns a DB connection object depending on the environment
    /// </summary>
    public static Hashtable getConnectionObject()
    {
        Hashtable connectionString = ServiceHelper.getDBNamesAndConnectionStrings();
        Hashtable dbConnectionObj = new Hashtable();
        SqlConnection appConnection = new SqlConnection((string)connectionString["connectionStringApp"]);
        dbConnectionObj.Add("appConnection", appConnection);
        return dbConnectionObj;
    }

    /// <summary>
    /// Reads all the three connection strings from web.config and returns a Hashtable of DB names.
    /// </summary>
    public static Hashtable getDBNamesAndConnectionStrings()
    {
        string environmentType = HttpContext.Current.Request.Url.Host;
        string connectionStringApp;
        switch(environmentType)
        {
            case "dev.emunching.com":
                connectionStringApp = ConfigurationManager.ConnectionStrings["devVCon"].ConnectionString;
                break;

            case "ppe.emunching.com":
                connectionStringApp = ConfigurationManager.ConnectionStrings["ppeVCon"].ConnectionString;
                break;

            case "www.emunching.com":
                connectionStringApp = ConfigurationManager.ConnectionStrings["proVCon"].ConnectionString;
                break;

            default:
                connectionStringApp = ConfigurationManager.ConnectionStrings["localVCon"].ConnectionString;
                break;
    
        }
        
        SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(connectionStringApp);
        
        Hashtable catalog = new Hashtable();
        catalog.Add("app", builder.InitialCatalog);
        catalog.Add("connectionStringApp", connectionStringApp);
            
        return catalog;
    }

}