﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Web.Services.Protocols;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Xml;
using System.Security.Cryptography;
using System.IO;
using System.Configuration;
using System.Text;
using System.Net.Mail;
using System.Net;
using Utilities;
using Newtonsoft.Json;

namespace eMunching
{
    [System.Web.Services.WebService(Namespace = "http://emunching.org/")]
    [System.Web.Services.WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    public class eMunchingWebServices : System.Web.Services.WebService
    {
        string strConn;

        string strSQL;

        //common mail variables that will be used across all the methods in this class
        string RestName;
        string From;
        string Subj;
        string Cc;
        string To;
        string Msg;
        Hashtable connectionObject = ServiceHelper.getDBNamesAndConnectionStrings();

        #region Private Methods

        /// <summary>
        /// This method authenticates the web service request.
        /// </summary>
        /// <param name="UserName">UserName</param>
        /// <param name="PassWord">PassWord</param>
        private static void AuthenticateWebRequest(string UserName, string PassWord)
        {
            if (UserName == null | PassWord == null)
            {
                throw new NullReferenceException("No credentials were specified.");
            }
            else if (UserName == null)
            {
                throw new NullReferenceException("Username was not supplied for authentication.");
            }
            else if (PassWord == null)
            {
                throw new NullReferenceException("Password was not supplied for authentication.");
            }
            else if (UserName != "eMunch" || PassWord != "idnlgeah11")
            {
                throw new Exception("Please pass the proper username and password for this service.");
            }
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML Document of Restaurant data")]
        public XmlDocument GetRestaurantsXML(string UserName, string PassWord)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetRestaurantData", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Restaurants>";
                    while (dr.Read())
                    {
                        XDtl += "<Restaurant><ID>" + dr[0].ToString() + "</ID><Name>" + dr[1].ToString() + "</Name></Restaurant>";
                    }
                    XDtl += "</Restaurants>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;
                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML Document of Restaurant Menu Item Groups.")]
        public XmlDocument GetRestaurantsMenuItemGroups_XML(string UserName, string PassWord, string RestID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetMenuItemGroups '" + RestID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantMenuGroups>";
                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();

                        XDtl += "<Group>" + "<ID>" + Str0.Trim() + "</ID>" + "<GroupName>" + Str1.Trim() + "</GroupName>" + "<GroupDesc>" + Str2.Trim() + "</GroupDesc>" + "<GroupImage>" + Str3.Trim() + "</GroupImage>" + "</Group>";
                    }
                    XDtl += "</RestaurantMenuGroups>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="UserID"></param>
        /// <param name="RestID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns Boolean value of Success|Failure for successfully sending an email with password.")]
        public XmlDocument GetForgottenPassword_XML(string UserName, string PassWord, string UserID, string RestID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetForgottenPwd '" + UserID + "','" + RestID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<ForgottenPwdSent>";
                    while (dr.Read())
                    {
                        To = dr[0].ToString();
                        Cc = dr[1].ToString();
                        Subj = dr[2].ToString();
                        Msg = dr[3].ToString();
                        From = dr[4].ToString();
                        RestName = dr[5].ToString();
                        bool Str0 = (MailHelper.SendMail(To, Cc.Trim(), Subj, Msg, From, RestName)) ? true : false;
                        XDtl += "<EmailSent>" + "<Sent>" + Str0 + "</Sent>" + "</EmailSent>";
                    }
                    XDtl += "</ForgottenPwdSent>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document of Restaurant Menu Items data")]
        public XmlDocument GetRestaurantMenuItems_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetRestaurantMenuItems '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantMenuItems>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        string Str8 = null;
                        string Str9 = null;
                        string Str10 = null;
                        string Str11 = null;
                        string Str12 = null;
                        string Str13 = null;
                        string Str14 = null;
                        string Str15 = null;
                        string Str16 = null;
                        string Str17 = null;
                        string Str18 = null;
                        string Str19 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        Str7 = dr[7] == null ? "" : dr[7].ToString();
                        Str8 = dr[8] == null ? "" : dr[8].ToString();
                        Str9 = dr[9] == null ? "" : dr[9].ToString();
                        Str10 = dr[10] == null ? "" : dr[10].ToString();
                        Str11 = dr[11] == null ? "" : dr[11].ToString();
                        Str12 = dr[12] == null ? "" : dr[12].ToString();
                        Str13 = dr[13] == null ? "" : dr[13].ToString();
                        Str14 = dr[14] == null ? "" : dr[14].ToString();
                        Str15 = dr[15] == null ? "" : dr[15].ToString();
                        Str16 = dr[16] == null ? "" : dr[16].ToString();
                        Str17 = dr[17] == null ? "" : dr[17].ToString();
                        Str18 = dr[18] == null ? "" : dr[18].ToString();
                        Str19 = dr[19] == null ? "" : dr[19].ToString();
                        XDtl += "<MenuItem>" + "<ID>" + Str0.Trim() + "</ID>" + "<Restaurant>" + Str1.Trim() + "</Restaurant>" + "<RestaurantName>" + Str2.Trim() + "</RestaurantName>" + "<MenuGroup>" + Str3.Trim() + "</MenuGroup>" + "<Breakfast>" + Str4.Trim() + "</Breakfast>" + "<MorningTeaElevenses>" + Str5.Trim() + "</MorningTeaElevenses>" + "<Brunch>" + Str6.Trim() + "</Brunch>" + "<Lunch>" + Str7.Trim() + "</Lunch>" + "<Dinner>" + Str8.Trim() + "</Dinner>" + "<AfternoonTea>" + Str9.Trim() + "</AfternoonTea>" + "<Supper>" + Str10.Trim() + "</Supper>" + "<Item>" + Str11.Trim() + "</Item>" + "<ItemDesc>" + Str12.Trim() + "</ItemDesc>" + "<ItemPrice>" + Str13.Trim() + "</ItemPrice>" + "<ComboPrice>" + Str14.Trim() + "</ComboPrice>" + "<PriceSchedule>" + Str15.Trim() + "</PriceSchedule>" + "<Archive>" + Str16.Trim() + "</Archive>" + "<ChildsPlate>" + Str17.Trim() + "</ChildsPlate>" + "<Veg>" + Str18.Trim() + "</Veg>" + "<ChefSpecial>" + Str19.Trim() + "</ChefSpecial>" + "</MenuItem>";
                    }

                    XDtl += "</RestaurantMenuItems>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the Restaurant Reservation Configuration")]
        public XmlDocument GetRestaurantResvConfig_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetRestaurantResvConfig '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantResvConfig>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        Str7 = dr[7] == null ? "" : dr[7].ToString();
                        XDtl += "<ResvConfig>" + "<Enabled>" + Str0.Trim() + "</Enabled>" + "<WeeksInAdvance>" + Str1.Trim() + "</WeeksInAdvance>" + "<WeekDayStart>" + Str2.Trim() + "</WeekDayStart>" + "<WeekDayStop>" + Str3.Trim() + "</WeekDayStop>" + "<StartTime>" + Str4.Trim() + "</StartTime>" + "<StopTime>" + Str5.Trim() + "</StopTime>" + "<Interval>" + Str6.Trim() + "</Interval>" + "<TableThreshold>" + Str7.Trim() + "</TableThreshold>" + "</ResvConfig>";
                    }

                    XDtl += "</RestaurantResvConfig>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="UserID"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the specified UserID and Restaurant")]
        public XmlDocument GetMyReviews_XML(string UserName, string PassWord, string UserID, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetMyReviews '" + UserID + "','" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<MyReviews>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        XDtl += "<Review>" + "<ID>" + Str0.Trim() + "</ID>" + "<Restaurant>" + Str1.Trim() + "</Restaurant>" + "<Location>" + Str2.Trim() + "</Location>" + "<Rating>" + Str3.Trim() + "</Rating>" + "<ReviewText>" + Str4.Trim() + "</ReviewText>" + "<ReviewDate>" + Str5.Trim() + "</ReviewDate>" + "</Review>";
                    }

                    XDtl += "</MyReviews>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the User Reviews of a specified Restaurant")]
        public XmlDocument GetReviews_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetReviews '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Reviews>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        XDtl += "<Review>" + "<ID>" + Str0.Trim() + "</ID>" + "<Restaurant>" + Str1.Trim() + "</Restaurant>" + "<Location>" + Str2.Trim() + "</Location>" + "<Rating>" + Str3.Trim() + "</Rating>" + "<ReviewText>" + Str4.Trim() + "</ReviewText>" + "<ReviewDate>" + Str5.Trim() + "</ReviewDate>" + "<ReviewerName>" + Str6.Trim() + "</ReviewerName>" + "</Review>";
                    }

                    XDtl += "</Reviews>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the Events of a specified Restaurant")]
        public XmlDocument GetEvents_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetEvents '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Events>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        XDtl += "<Event>" + "<ID>" + Str0.Trim() + "</ID>" + "<Restaurant>" + Str1.Trim() + "</Restaurant>" + "<Location>" + Str2.Trim() + "</Location>" + "<EventTitle>" + Str3.Trim() + "</EventTitle>" + "<EventDesc>" + Str4.Trim() + "</EventDesc>" + "<EventDate>" + Str5.Trim() + "</EventDate>" + "<EventTime>" + Str6.Trim() + "</EventTime></Event>";
                    }

                    XDtl += "</Events>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the Deals of a specified Restaurant")]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public XmlDocument GetDeals_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            string jsonReturn = "";
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetDeals '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Deals>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        string Str8 = null;
                        string Str9 = null;
                        string Str10 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        Str7 = dr[7] == null ? "" : dr[7].ToString();
                        Str8 = dr[8] == null ? "" : dr[8].ToString();
                        Str9 = dr[9] == null ? "" : dr[9].ToString();
                        XDtl += "<Deal>" + "<ID>" + Str0.Trim() + "</ID>" + "<Restaurant>" + Str1.Trim() + "</Restaurant>" + "<Title>" + Str2.Trim() + "</Title>" + "<Desc>" + Str3.Trim() + "</Desc>" + "<Thumbnail>" + Str4.Trim() + "</Thumbnail>" + "<Image>" + Str5.Trim() + "</Image>" + "<Type>" + Str6.Trim() + "</Type>" + "<Value>" + Str7.Trim() + "</Value>" + "<Starts>" + Str8.Trim() + "</Starts>" + "<Expires>" + Str9.Trim() + "</Expires></Deal>";
                    }

                    XDtl += "</Deals>";
                    xmlDoc.LoadXml(XDtl);
                    
                    //jsonReturn = Newtonsoft.Json.JsonConvert.SerializeXmlNode(xmlDoc);
                    //return jsonReturn;
                    //this.Context.Response.Write(jsonReturn);
                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            //this.Context.Response.Write(jsonReturn);
            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the history and contact details of a specified Restaurant")]
        public XmlDocument GetRestaurantAbout_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetRestaurantAbout '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<AboutUs>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        string Str8 = null;
                        string Str9 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        Str7 = dr[7] == null ? "" : dr[7].ToString();
                        Str8 = dr[8] == null ? "" : dr[8].ToString();
                        Str9 = dr[9] == null ? "" : dr[9].ToString();

                        XDtl += "<About>" + "<ID>" + Str0.Trim() + "</ID>" + "<Restaurant>" + Str1.Trim() + "</Restaurant>" + "<eMunchingURL>" + Str2.Trim() + "</eMunchingURL>" + "<RestaurantURL>" + Str3.Trim() + "</RestaurantURL>" + "<FacebookURL>" + Str4.Trim() + "</FacebookURL>" + "<TwitterHandle>" + Str5.Trim() + "</TwitterHandle>" + "<PrimaryCountry>" + Str6.Trim() + "</PrimaryCountry>" + "<History>" + Str7.Trim() + "</History>" + "<MainEmailContact>" + Str8.Trim() + "</MainEmailContact>" + "<HoursOfOperation>" + Str9.Trim() + "</HoursOfOperation>" + "</About>";
                    }

                    XDtl += "</AboutUs>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <param name="MealType"></param>
        /// <param name="DealType"></param>
        /// <param name="MenuItemType"></param>
        /// <param name="MealCategory"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document of Restaurant Menu Items according to the parameters passed:<br><br> MealType - Values: Breakfast, Brunch, Morning Tea (Elevenses), Lunch, Dinner, Afternoon Tea, Supper = 1,2,3,4,5,6,7<br>DealType - Values: All, ChefSpecials, FeaturedDeals = 0,1,2<br>MenuItemType - Values: All, Veg, NonVeg = 0,1,2<br>MenuItemCategory - Values: [Retrieved from the GetMealCategories Method].")]
        public XmlDocument GetRestaurantMenuItemsAll_XML(string UserName, string PassWord, string RestaurantID, string MealType, string DealType, string MenuItemType, string MealCategory)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetRestaurantMenuItemsAll '" + RestaurantID + "','" + MealType + "','" + DealType + "','" + MenuItemType + "','" + MealCategory + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantMenuItems>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        string Str8 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        Str7 = dr[7] == null ? "" : dr[7].ToString();
                        Str8 = dr[8] == null ? "" : dr[8].ToString();
                        XDtl += "<MenuItem>" + "<ID>" + Str0.Trim() + "</ID>" + "<ItemImage1>" + Str1.Trim() + "</ItemImage1>" + "<ItemImage2>" + Str2.Trim() + "</ItemImage2>" + "<ItemImage3>" + Str3.Trim() + "</ItemImage3>" + "<Item>" + Str4.Trim() + "</Item>" + "<ItemDesc>" + Str5.Trim() + "</ItemDesc>" + "<ItemPrice>" + Str6.Trim() + "</ItemPrice>" + "<ComboPrice>" + Str7.Trim() + "</ComboPrice>" + "<DiscountPrice>" + Str8.Trim() + "</DiscountPrice>" + "</MenuItem>";
                    }

                    XDtl += "</RestaurantMenuItems>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document of Restaurant Locations")]
        public XmlDocument GetRestaurantLocations_XML(string UserName, string PassWord, string RestaurantID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetRestaurantLocations '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantLocations>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        string Str6 = null;
                        string Str7 = null;
                        string Str8 = null;
                        string Str9 = null;
                        string Str10 = null;
                        string Str11 = null;
                        string Str12 = null;
                        string Str13 = null;
                        string Str14 = null;
                        string Str15 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        Str6 = dr[6] == null ? "" : dr[6].ToString();
                        Str7 = dr[7] == null ? "" : dr[7].ToString();
                        Str8 = dr[8] == null ? "" : dr[8].ToString();
                        Str9 = dr[9] == null ? "" : dr[9].ToString();
                        Str10 = dr[10] == null ? "" : dr[10].ToString();
                        Str11 = dr[11] == null ? "" : dr[11].ToString();
                        Str12 = dr[12] == null ? "" : dr[12].ToString();
                        Str13 = dr[13] == null ? "" : dr[13].ToString();
                        Str14 = dr[14] == null ? "" : dr[14].ToString();
                        Str15 = dr[15] == null ? "" : dr[15].ToString();
                        XDtl += "<Location>" + "<LocaID>" + Str0.Trim() + "</LocaID>" + "<RName>" + Str1.Trim() + "</RName>" + "<LName>" + Str2.Trim() + "</LName>" + "<StreetAddress>" + Str3.Trim() + "</StreetAddress>" + "<City>" + Str4.Trim() + "</City>" + "<Region>" + Str5.Trim() + "</Region>" + "<Country>" + Str6.Trim() + "</Country>" + "<Latitude>" + Str7.Trim() + "</Latitude>" + "<Longitude>" + Str8.Trim() + "</Longitude>" + "<PhoneNumber>" + Str9.Trim() + "</PhoneNumber>" + "<EmailAddress>" + Str10.Trim() + "</EmailAddress>" + "<WebSite>" + Str11.Trim() + "</WebSite>" + "<FacebookUrl>" + Str12.Trim() + "</FacebookUrl>" + "<TwitterHandle>" + Str13.Trim() + "</TwitterHandle>" + "<HoursOfOperation>" + Str14.Trim() + "</HoursOfOperation>" + "<MultipleMenus>" + Str15.Trim() + "</MultipleMenus>" + "</Location>";
                    }

                    XDtl += "</RestaurantLocations>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="UserId"></param>
        /// <param name="UserPassword"></param>
        /// <param name="Phone"></param>
        /// <param name="Location"></param>
        /// <returns></returns>
        [WebMethod(Description = "Update User Profile")]
        public object UpdateProfile(string UserName, string PassWord, string UserId, string UserPassword, string Phone, string Location)
        {

            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "EXEC p_Svc_UpdateProfile @UserId,@UserPassword,@Phone,@Location";

            int recordsInserted = 0;

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    var _with1 = command;
                    _with1.Parameters.AddWithValue("@UserId", UserId);
                    _with1.Parameters.AddWithValue("@UserPassword", UserPassword);
                    _with1.Parameters.AddWithValue("@Phone", Phone);
                    _with1.Parameters.AddWithValue("@Location", Location);
                    cn.Open();
                    recordsInserted = command.ExecuteNonQuery();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                    return recordsInserted;
                }
            }

            strSQL = null;

            return recordsInserted;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="UserId"></param>
        /// <param name="Restaurant"></param>
        /// <param name="LocaID"></param>
        /// <param name="Rating"></param>
        /// <param name="Review"></param>
        /// <returns></returns>
        [WebMethod(Description = "Submit a Review")]
        public object CreateReview(string UserName, string PassWord, string UserId, string Restaurant, string LocaID, string Rating, string Review)
        {

            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "EXEC p_Svc_CreateReview @UserId,@Restaurant,@LocaID,@Rating,@Review";

            int recordsInserted = 0;

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    var _with2 = command;
                    _with2.Parameters.AddWithValue("@UserId", UserId);
                    _with2.Parameters.AddWithValue("@Restaurant", Restaurant);
                    _with2.Parameters.AddWithValue("@LocaID", LocaID);
                    _with2.Parameters.AddWithValue("@Rating", Rating);
                    _with2.Parameters.AddWithValue("@Review", Review);
                    cn.Open();
                    recordsInserted = command.ExecuteNonQuery();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                    return recordsInserted;
                }
            }

            strSQL = null;

            return recordsInserted;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <param name="UserID"></param>
        /// <param name="UserPassword"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns Bool value of Login Status")]
        public XmlDocument LoginUser(string UserName, string PassWord, string RestaurantID, string UserID, string UserPassword)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_LoginUser '" + UserID + "','" + UserPassword + "','" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Login>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();

                        XDtl += "<IsValid>" + Str0.Trim() + "</IsValid>" + "<FirstName>" + Str1.Trim() + "</FirstName>" + "<LastName>" + Str2.Trim() + "</LastName>" + "<PhoneNumber>" + Str3.Trim() + "</PhoneNumber>" + "<PrefLoca>" + Str4.Trim() + "</PrefLoca>";

                    }
                    XDtl += "</Login>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;
                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Get User Details By UserID")]
        public XmlDocument GetUserByUserID(string UserName, string PassWord, string UserID)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetUserByUserID '" + UserID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No User Details Available</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<User>";
                    while (dr.Read())
                    {
                        XDtl += "<Details>" + "<ID>" + dr[0].ToString() + "</ID>" + "<FullName>" + dr[1].ToString() + "</FullName>" + "<Email>" + dr[2].ToString() + "</Email>" + "<Salt>" + dr[3].ToString() + "</Salt>" + "<Password>" + dr[4].ToString() + "</Password>" + "</Details>";
                    }
                    XDtl += "</User>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;
                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="UserID"></param>
        /// <param name="AuthenticationCode"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns Bool value of Authentication Status")]
        public XmlDocument AuthenticateUser(string UserName, string PassWord, string UserID, string AuthenticationCode)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_AuthenticateUser '" + UserID + "','" + AuthenticationCode + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Authenticated>";
                    while (dr.Read())
                    {
                        XDtl += "<IsValid>" + dr[0].ToString() + "</IsValid>";
                    }
                    XDtl += "</Authenticated>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;
                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <param name="RestaurantLocaID"></param>
        /// <param name="FirstName"></param>
        /// <param name="LastName"></param>
        /// <param name="Email"></param>
        /// <param name="Salt"></param>
        /// <param name="RPassword"></param>
        /// <param name="Phone"></param>
        /// <returns></returns>
        [WebMethod(Description = "Register User for Restaurant.")]
        public XmlDocument RegisterRestaurantUser(string UserName, string PassWord, string RestaurantID, string RestaurantLocaID, string FirstName, string LastName, string Email, string Salt, string RPassword, string Phone)
        {

            XmlDocument xmlDoc = new XmlDocument();
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";

            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "p_Svc_CreateRestaurantUser";

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlParameter Result = new SqlParameter("@Result", SqlDbType.NVarChar, 500);
                    Result.Direction = ParameterDirection.Output;

                    var _with3 = command;
                    _with3.Parameters.AddWithValue("@RestaurantID", RestaurantID);
                    _with3.Parameters.AddWithValue("@RestaurantLocaID", RestaurantLocaID);
                    _with3.Parameters.AddWithValue("@FirstName", FirstName);
                    _with3.Parameters.AddWithValue("@LastName", LastName);
                    _with3.Parameters.AddWithValue("@Salt", Salt);
                    _with3.Parameters.AddWithValue("@Password", RPassword);
                    _with3.Parameters.AddWithValue("@Email", Email);
                    _with3.Parameters.AddWithValue("@Phone", Phone);
                    _with3.Parameters.Add(Result);
                    cn.Open();
                    dr = command.ExecuteReader();
                    if (dr.HasRows == false)
                    {
                        Output = "<error>No Rows</error>";
                    }
                    else
                    {
                        string XDtl = null;
                        XDtl = "<ValidReturn>";
                        while (dr.Read())
                        {
                            XDtl += "<ReturnString>" + dr[0].ToString() + "</ReturnString>";
                            RestName = dr[1].ToString();
                            From = dr[2].ToString();
                            Subj = dr[3].ToString();
                            Cc = dr[4].ToString();
                            To = dr[5].ToString();
                            Msg = dr[6].ToString();

                        }
                        XDtl += "</ValidReturn>";
                        xmlDoc.LoadXml(XDtl);
                        MailHelper.SendMail(To, Cc, Subj, Msg, From, RestName);
                        return xmlDoc;
                    }

                }
                catch (Exception ex)
                {
                    Output = "<error>" + ex.ToString() + "</error>";
                }
                finally
                {
                    cn.Close();
                }
            }

            xmlDoc.LoadXml(Output);
            return xmlDoc;

        }

        /// <summary>
        /// This method creates an order.
        /// </summary>
        /// <param name="UserName">string UserName</param>
        /// <param name="PassWord">string PassWord</param>
        /// <param name="OrderName">string OrderName</param>
        /// <param name="RestaurantID">string RestaurantId</param>
        /// <param name="RestaurantLocaID">string RestaurantLocaID</param>
        /// <param name="UserId">string UserId</param>
        /// <param name="MenuItems">string MenuItems</param>
        /// <returns>An object that tells us how many records were inserted into the Order</returns>
        [WebMethod(Description = "Create Order for User, for Restaurant.")]
        public object CreateOrder(string UserName, string PassWord, string OrderName, string RestaurantID, string RestaurantLocaID, string UserId, string MenuItems)
        {
            SqlDataReader dr = null;

            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "EXEC p_Svc_CreateOrder @OrderName,@UserId,@RestaurantID,@RestaurantLocaID,@MenuItems";

            bool recordsInserted = false;

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    var _with4 = command;
                    _with4.Parameters.AddWithValue("@OrderName", OrderName);
                    _with4.Parameters.AddWithValue("@UserId", UserId);
                    _with4.Parameters.AddWithValue("@RestaurantID", RestaurantID);
                    _with4.Parameters.AddWithValue("@RestaurantLocaID", RestaurantLocaID);
                    _with4.Parameters.AddWithValue("@MenuItems", MenuItems);
                    cn.Open();
                    //recordsInserted = command.ExecuteNonQuery();
                    dr = command.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            To = dr[0].ToString();
                            Cc = dr[1].ToString();
                            Subj = dr[2].ToString();
                            Msg = dr[3].ToString();
                            From = dr[4].ToString();
                            RestName = dr[5].ToString();
                        }
                        recordsInserted = MailHelper.SendMail(To, Cc, Subj, Msg, From, RestName);
                    }
                    cn.Close();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                    return recordsInserted;
                }
            }

            strSQL = null;

            return recordsInserted;

        }

        /// <summary>
        /// This method creates a reservation
        /// </summary>
        /// <param name="UserName">string UserName</param>
        /// <param name="PassWord">string PassWord</param>
        /// <param name="ResName">string that represents the Name on the reservation</param>
        /// <param name="CallBackNumber">string that represents a callback number for the reservation</param>
        /// <param name="RestaurantID">string RestaurantID</param>
        /// <param name="RestaurantLocaID">string RestaurantLocaID</param>
        /// <param name="UserID">string UserID</param>
        /// <param name="NumGuests">string NumGuests</param>
        /// <param name="TimeSlot">string TimeSlot</param>
        /// <returns></returns>
        [WebMethod(Description = "Create Reservation for User, for Restaurant.")]
        public XmlDocument CreateReservation(string UserName, string PassWord, string ResName, string CallBackNumber, string RestaurantID, string RestaurantLocaID, string UserID, string NumGuests, string TimeSlot)
        {

            XmlDocument xmlDoc = new XmlDocument();
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";

            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "p_Svc_CreateReservations";

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlParameter Result = new SqlParameter("@Result", SqlDbType.NVarChar, 500);
                    Result.Direction = ParameterDirection.Output;

                    var _with5 = command;
                    _with5.Parameters.AddWithValue("@ResName", ResName);
                    _with5.Parameters.AddWithValue("@CallBackNumber", CallBackNumber);
                    _with5.Parameters.AddWithValue("@RestaurantID", RestaurantID);
                    _with5.Parameters.AddWithValue("@RestaurantLocaID", RestaurantLocaID);
                    _with5.Parameters.AddWithValue("@UserID", UserID);
                    _with5.Parameters.AddWithValue("@NumGuests", NumGuests);
                    _with5.Parameters.AddWithValue("@TimeSlot", TimeSlot);
                    _with5.Parameters.Add(Result);

                    cn.Open();
                    dr = command.ExecuteReader();
                    if (dr.HasRows == false)
                    {
                        Output = "<error>No Rows</error>";
                    }
                    else
                    {
                        string XDtl = null;
                        XDtl = "<ValidReturn>";
                        while (dr.Read())
                        {
                            To = dr[1].ToString();
                            Cc = dr[2].ToString();
                            Subj = dr[3].ToString();
                            Msg = dr[4].ToString();
                            From = dr[5].ToString();
                            RestName = dr[6].ToString();
                            XDtl += "<ReturnString>" + dr[0].ToString() + "</ReturnString>";
                        }
                        XDtl += "</ValidReturn>";
                        xmlDoc.LoadXml(XDtl);
                        MailHelper.SendMail(To, Cc, Subj, Msg, From, RestName);
                        return xmlDoc;
                    }

                }
                catch (Exception ex)
                {
                    Output = "<error>" + ex.ToString() + "</error>";
                }
                finally
                {
                    cn.Close();
                }
            }

            xmlDoc.LoadXml(Output);
            return xmlDoc;

        }

        /// <summary>
        /// Given a ReservationId, and valid credentials, this method cancels the reservations
        /// </summary>
        /// <param name="UserName">string UserName</param>
        /// <param name="PassWord">string PassWord</param>
        /// <param name="ResId">string ReservationId</param>
        /// <returns></returns>
        [WebMethod(Description = "Cancel Reservation.")]
        public object CancelReservation(string UserName, string PassWord, string ResId)
        {
            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "EXEC p_Svc_CancelReservation @ResId";
            SqlDataReader dr = null;
            bool recordsInserted = false;

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    var _with6 = command;
                    _with6.Parameters.AddWithValue("@ResId", ResId);
                    cn.Open();
                    dr = command.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        while (dr.Read())
                        {
                            To = dr[0].ToString();
                            Cc = dr[1].ToString();
                            Subj = dr[2].ToString();
                            Msg = dr[3].ToString();
                            From = dr[4].ToString();
                            RestName = dr[5].ToString();
                        }
                        recordsInserted = MailHelper.SendMail(To, Cc, Subj, Msg, From, RestName);
                    }
                    cn.Close();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                    return recordsInserted;
                }
            }

            strSQL = null;

            return recordsInserted;

        }

        /// <summary>
        /// Given a ReservationId, and valid credentials, this method cancels the reservations
        /// </summary>
        /// <param name="UserName">string UserName</param>
        /// <param name="PassWord">string PassWord</param>
        /// <param name="ResId">string ReservationId</param>
        /// <returns></returns>
        [WebMethod(Description = "Restaurant Display Settings for Menu, Events and Deals.<br> Display Setting: 1 - Traditional Menu, 2 - Thumb and Signature menu, 3 - Signature menu")]
        public XmlDocument GetRestaurantDisplaySettings_XML(string UserName, string PassWord, string ResId)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("SELECT * FROM dbo.MobileAppDisplaySettings WHERE Restaurant='"+ ResId +"'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantLocations>";

                    while (dr.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        string Str2 = null;
                        string Str3 = null;
                        string Str4 = null;
                        string Str5 = null;
                        Str0 = dr[0] == null ? "" : dr[0].ToString();
                        Str1 = dr[1] == null ? "" : dr[1].ToString();
                        Str2 = dr[2] == null ? "" : dr[2].ToString();
                        Str3 = dr[3] == null ? "" : dr[3].ToString();
                        Str4 = dr[4] == null ? "" : dr[4].ToString();
                        Str5 = dr[5] == null ? "" : dr[5].ToString();
                        XDtl += "<Setting><Restaurant>" + Str1.Trim() + "</Restaurant>" + "<EventMenuDeal>" + Str2.Trim() + "</EventMenuDeal>" + "<Type>" + Str3.Trim() + "</Type>" + "<CreatedTime>" + Str4.Trim() + "</CreatedTime>" + "<LastModified>" + Str5.Trim() + "</LastModified></Setting>";
                    }

                    XDtl += "</RestaurantLocations>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;
                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="DeviceToken"></param>
        /// <param name="RestaurantID"></param>
        /// <returns></returns>
        [WebMethod(Description = "Submit a Review")]
        public object RegisterDeviceForNotification(string UserName, string PassWord, string DeviceToken, string RestaurantID)
        {
            string CurrentDate = Convert.ToString(System.DateTime.Now);
            AuthenticateWebRequest(UserName, PassWord);

            strConn = (string)connectionObject["connectionStringApp"];
            strSQL = "INSERT INTO [dbo].[DeviceToken] (DeviceToken, Restaurant, CreatedTime) VALUES (@DeviceToken, @RestaurantID, getDate())";

            int recordsInserted = 0;

            using (SqlConnection cn = new SqlConnection(strConn))
            {
                try
                {
                    SqlCommand command = new SqlCommand(strSQL, cn);
                    var _with4 = command;
                    _with4.Parameters.AddWithValue("@DeviceToken", DeviceToken);
                    _with4.Parameters.AddWithValue("@RestaurantID", RestaurantID);
                    cn.Open();
                    recordsInserted = command.ExecuteNonQuery();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                    return recordsInserted;
                }
            }

            strSQL = null;

            return recordsInserted;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DeviceToken"></param>
        /// <param name="RestId"></param>
        /// <returns></returns>
        [WebMethod(Description = "Get All unread notifications sent by APNS per Device per Restaurant")]
        public XmlDocument GetNotificationsSentToAPNS_XML(string UserName, string PassWord, string DeviceToken, string RestId)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection connection = null;
            SqlCommand command = null;
            SqlDataReader dataReader = null;
            string sql = "";
            dynamic Output = null;
            Output = "<nothing></nothing>";
            connection = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                connection.Open();
                sql = "SELECT COUNT(*) as notificationCount, 'Deal' as ActionType FROM Deals WHERE Restaurant="+RestId+" AND id NOT IN (SELECT DealID FROM RestaurantDealsVisited WHERE Restaurant="+RestId+" AND DeviceToken='"+DeviceToken+"')";
                sql += " UNION ";
                sql += "SELECT COUNT(*) as notificationCount, 'Event' as ActionType FROM RestaurantEvents WHERE Restaurant="+RestId+" AND EventID NOT IN (SELECT EventID FROM RestaurantEventsVisited WHERE Restaurant="+RestId+" AND DeviceToken='"+DeviceToken+"')";
                command = new SqlCommand(sql, connection);
                dataReader = command.ExecuteReader();
                if (dataReader.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<RestaurantNotification>";

                    while (dataReader.Read())
                    {
                        string Str0 = null;
                        string Str1 = null;
                        Str0 = dataReader["notificationCount"] == null ? "" : dataReader["notificationCount"].ToString();
                        Str1 = dataReader["ActionType"] == null ? "" : dataReader["ActionType"].ToString();
                        XDtl += "<Notification><NotificationCount>" + Str0.Trim() + "</NotificationCount>" + "<ActionType>" + Str1.Trim() + "</ActionType></Notification>";
                    }

                    XDtl += "</RestaurantNotification>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;
                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                connection.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="DeviceToken"></param>
        /// <param name="RestId"></param>
        /// <param name="ActionType"></param>
        /// <returns></returns>
        [WebMethod(Description = "Set Notifications Read By Device By Restaurant By ActionType <br> Action Type : Event, Deal, Menu")]
        public object SetNotificationsReadByDeviceByRestaurantByActionType(string UserName, string PassWord, string DeviceToken, string RestId, string ActionType)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection connection = null;
            SqlCommand sql = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            connection = new SqlConnection(connectionString);
            int recordsInserted = 0;
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                connection.Open();
                sql = new SqlCommand("UPDATE NotificationsSentToAPNS SET ReadByDevice=1 WHERE DeviceToken = '" + DeviceToken + "' AND Restaurant="+RestId+" AND ActionType='"+ActionType+"'", connection);
                recordsInserted = sql.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                connection.Close();
            }

            return recordsInserted;
        }

        /// <summary>
        /// Sets the Deal As Read By Device By Restaurant
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestId"></param>
        /// <param name="DealId"></param>
        /// <param name="DeviceToken"></param>
        /// <returns></returns>
        [WebMethod(Description = "Set Deal Veiwed By Device By Restaurant")]
        public object SetDealViewedByDevice(string UserName, string PassWord, string RestId, string DealId, string DeviceToken)
        {
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection connection = new SqlConnection(connectionString);
            dynamic Output = "<nothing></nothing>";
            int recordsInserted = 0;
            try
            {
                AuthenticateWebRequest(UserName, PassWord);
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand("INSERT INTO dbo.RestaurantDealsVisited (Restaurant, DealID, DeviceToken) VALUES (@RestId, @DealId, @DeviceToken)", connection);
                var _with = sqlCommand;
                _with.Parameters.AddWithValue("@RestId", RestId);
                _with.Parameters.AddWithValue("@DealID", DealId);
                _with.Parameters.AddWithValue("@DeviceToken", DeviceToken);
                recordsInserted = sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                connection.Close();
            }

            return recordsInserted;
        }

        /// <summary>
        /// Sets the Event As Read By Device By Restaurant
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestId"></param>
        /// <param name="EventId"></param>
        /// <param name="DeviceToken"></param>
        /// <returns></returns>
        [WebMethod(Description = "Set Event Veiwed By Device By Restaurant")]
        public object SetEventViewedByDevice(string UserName, string PassWord, string RestId, string EventId, string DeviceToken)
        {
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection connection = new SqlConnection(connectionString);
            dynamic Output = "<nothing></nothing>";
            int recordsInserted = 0;
            try
            {
                AuthenticateWebRequest(UserName, PassWord);
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand("INSERT INTO dbo.RestaurantEventsVisited (Restaurant, EventID, DeviceToken) VALUES (@RestId, @EventId, @DeviceToken)", connection);
                var _with = sqlCommand;
                _with.Parameters.AddWithValue("@RestId", RestId);
                _with.Parameters.AddWithValue("@EventID", EventId);
                _with.Parameters.AddWithValue("@DeviceToken", DeviceToken);
                recordsInserted = sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                connection.Close();
            }

            return recordsInserted;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <param name="DeviceToken"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the Deals with IsNew flag of a specified Restaurant")]
        public XmlDocument GetDealsExtended_XML(string UserName, string PassWord, string RestaurantID, string DeviceToken)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            DataTable dataTable = new DataTable();
            SqlDataReader dr = null;
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetDeals '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Deals>";
                    dataTable.Load(dr);
                    dr.Close();
                    foreach (DataRow row in dataTable.Rows)
                    {
                        sql = new SqlCommand("SELECT COUNT(*) FROM RestaurantDealsVisited WHERE Restaurant="+RestaurantID+" AND DealID="+row["id"]+" AND DeviceToken='"+DeviceToken+"'",con);
                        int count = (int)sql.ExecuteScalar();
                        XDtl += "<Deal>" + "<ID>" + row["id"] + "</ID>" + "<Restaurant>" + row["name"] + "</Restaurant>" + "<Title>" + row["title"] + "</Title>" + "<Desc>" + row["description"] + "</Desc>" + "<Thumbnail>" + row["thumbnail"] + "</Thumbnail>" + "<Image>" + row["image"] + "</Image>" + "<Type>" + row["type"] + "</Type>" + "<Value>" + row["value"] + "</Value>" + "<Starts>" + row["startsFrom"] + "</Starts>" + "<Expires>" + row["expiresOn"] + "</Expires><IsNew>" + ((count > 0)?0:1) + "</IsNew></Deal>";
                    }
                    
                    XDtl += "</Deals>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="RestaurantID"></param>
        /// <param name="DeviceToken"></param>
        /// <returns></returns>
        [WebMethod(Description = "Returns XML document with the Events and IsNew flag of a specified Restaurant")]
        public XmlDocument GetEventsExtended_XML(string UserName, string PassWord, string RestaurantID, string DeviceToken)
        {
            XmlDocument xmlDoc = new XmlDocument();
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection con = null;
            SqlCommand sql = null;
            SqlDataReader dr = null;
            DataTable dataTable = new DataTable();
            dynamic Output = null;
            Output = "<nothing></nothing>";
            con = new SqlConnection(connectionString);
            try
            {
                AuthenticateWebRequest(UserName, PassWord);

                con.Open();
                sql = new SqlCommand("EXEC p_Svc_GetEvents '" + RestaurantID + "'", con);
                dr = sql.ExecuteReader();
                if (dr.HasRows == false)
                {
                    Output = "<error>No Rows</error>";
                }
                else
                {
                    string XDtl = null;
                    XDtl = "<Events>";
                    dataTable.Load(dr);
                    dr.Close();
                    foreach (DataRow row in dataTable.Rows)
                    {
                        sql = new SqlCommand("SELECT COUNT(*) FROM RestaurantEventsVisited WHERE Restaurant=" + RestaurantID + " AND EventID=" + row["EventID"] + " AND DeviceToken='" + DeviceToken + "'", con);
                        int count = (int)sql.ExecuteScalar();
                        XDtl += "<Event>" + "<ID>" + row["EventID"] + "</ID>" + "<Restaurant>" + row["RName"] + "</Restaurant>" + "<Location>" + row["LName"] + "</Location>" + "<EventTitle>" + row["EName"] + "</EventTitle>" + "<EventDesc>" + row["Description"] + "</EventDesc>" + "<EventDate>" + row["Date"] + "</EventDate>" + "<EventTime>" + row["Time"] + "</EventTime><IsNew>" + ((count > 0) ? 0 : 1) + "</IsNew></Event>";
                    }

                    XDtl += "</Events>";
                    xmlDoc.LoadXml(XDtl);

                    return xmlDoc;

                }

            }
            catch (Exception ex)
            {
                Output = "<error>" + ex.ToString() + "</error>";
            }
            finally
            {
                con.Close();
            }

            xmlDoc.LoadXml(Output);

            return xmlDoc;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ActionType"></param>
        /// <param name="DeviceToken"></param>
        /// <param name="RestId"></param>
        /// <returns></returns>
        [WebMethod(Description = "Marks all the Events or Deals or Menu items visited by Restaurant by Device by Action. <br>Action Type: Event, Menu, Deal")]
        public object MarkEventsOrDealsOrMenuAsViewed(string UserName, string PassWord, string ActionType, string DeviceToken, string RestId)
        {
            string connectionString = (string)connectionObject["connectionStringApp"];
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = null;
            int recordsInserted = 0;
            try
            {
                AuthenticateWebRequest(UserName, PassWord);
                connection.Open();
                switch(ActionType)
                {
                    case "Event":
                        command = new SqlCommand("INSERT INTO RestaurantEventsVisited (Restaurant,EventID, DeviceToken) (SELECT " + RestId + " as Rest,EventID,'" + DeviceToken + "' FROM RestaurantEvents WHERE Restaurant=" + RestId + " AND EventID NOT IN (SELECT EventID FROM RestaurantEventsVisited WHERE Restaurant="+RestId+" AND DeviceToken='"+DeviceToken+"'))", connection);
                        break;
                    case "Deal":
                        command = new SqlCommand("INSERT INTO RestaurantDealsVisited (Restaurant,DealID, DeviceToken) (SELECT " + RestId + " as Rest,id,'" + DeviceToken + "' FROM Deals WHERE Restaurant=" + RestId + " AND id NOT IN (SELECT DealID FROM RestaurantDealsVisited WHERE Restaurant=" + RestId + " AND DeviceToken='" + DeviceToken + "'))", connection);
                        break;
                    case "Menu":
                        command = new SqlCommand("", connection);
                        break;
                    default:
                        break;
                }
                recordsInserted = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                connection.Close();
            }

            return recordsInserted;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// 
        [WebMethod(Description = "Bla Bla")]
        public void JsonWrapper( string callback, string input)
        {
            string[] inputList = input.Split('&');
            XmlDocument xmlDoc = new XmlDocument();
            string jsonReturn = "";
            Dictionary<string, string> inputVariables = new Dictionary<string,string>();
            foreach (string inputItem in inputList)
            {
                string[] variable = inputItem.Split('=');
                inputVariables.Add(variable[0], variable[1]);
            }

            switch (inputVariables["UserName"])
            {
                case "GetRestaurantMenuItemsAll_XML":
                    xmlDoc = GetRestaurantMenuItemsAll_XML(inputVariables["UserName"], inputVariables["PassWord"], inputVariables["RestaurantID"], inputVariables["MealType"], inputVariables["DealType"], inputVariables["MenuItemType"], inputVariables["MealCategory"]);
                    break;
                case "GetRestaurantMenuItems_XML":
                    xmlDoc = GetRestaurantMenuItems_XML(inputVariables["UserName"], inputVariables["PassWord"], inputVariables["RestaurantID"]);
                    break;
                case "GetRestaurantsMenuItemGroups_XML":
                    xmlDoc = GetRestaurantsMenuItemGroups_XML(inputVariables["UserName"], inputVariables["PassWord"], inputVariables["RestID"]);
                    break;
                default :
                    break;
            }
            //xmlDoc = GetDeals_XML(inputVariables["UserName"], inputVariables["PassWord"], inputVariables["RestaurantID"]);
            jsonReturn = Newtonsoft.Json.JsonConvert.SerializeXmlNode(xmlDoc);
            this.Context.Response.Write(callback+"("+ jsonReturn +")");
        }

        #endregion Public Methods
    }
}
